import Animation from "./components/Animation/Animation";

function App() {
  return (
    <div className="App">
      <Animation />
    </div>
  );
}

export default App;
